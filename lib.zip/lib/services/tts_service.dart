import 'package:gesacad/utils/platform_utils.dart';

/// Servicio singleton de Text-to-Speech — funciona en web y Android.
///
/// En WEB usa Web Speech API (dart:html) vía PlatformUtils.
/// En Android usa flutter_tts vía PlatformUtils.
class TtsService {
  TtsService._();
  static final TtsService instance = TtsService._();

  /// Indica si actualmente se está leyendo texto en voz alta.
  bool _leyendo = false;
  bool get leyendo => _leyendo;

  /// Texto que se está leyendo actualmente (para evitar repetir el mismo).
  String _textoActual = '';

  /// Lee [texto] en voz alta.
  ///
  /// Si ya se está leyendo el mismo texto, actúa como toggle y detiene.
  /// Si se está leyendo otro texto, cancela el anterior y comienza el nuevo.
  Future<void> speak(String texto) async {
    // Si es el mismo texto y está hablando → toggle (detener)
    if (_leyendo && _textoActual == texto) {
      await stop();
      return;
    }
    // Cancelar cualquier lectura anterior
    await stop();

    _leyendo     = true;
    _textoActual = texto;

    // PlatformUtils selecciona automáticamente web o Android
    PlatformUtils.speak(texto, lang: 'es-CO');

    // Estimar duración de lectura para resetear el estado
    // (la Web Speech API no tiene un Future real que esperamos)
    final duracion = Duration(milliseconds: 500 + texto.length * 55);
    Future.delayed(duracion, () {
      if (_textoActual == texto && _leyendo) {
        _leyendo     = false;
        _textoActual = '';
      }
    });
  }

  /// Detiene inmediatamente cualquier lectura en curso.
  Future<void> stop() async {
    PlatformUtils.stopSpeech();
    _leyendo     = false;
    _textoActual = '';
  }
}
