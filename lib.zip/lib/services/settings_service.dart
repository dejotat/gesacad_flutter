import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/tts_service.dart';

/// Servicio global de ajustes de la aplicación.
///
/// Gestiona: TalkBack (on/off) y tema visual (4 opciones).
/// Usa [ValueNotifier] para que la UI reaccione sin setState manual.
class AppSettings {
  AppSettings._();

  static final ValueNotifier<bool> talkBackEnabled = ValueNotifier(true);
  static final ValueNotifier<AppThemeType> currentTheme =
      ValueNotifier(AppThemeType.blue);

  static const _keyTalkBack = 'gesacad_talkback';
  static const _keyTheme = 'gesacad_theme';

  /// Carga los ajustes guardados desde SharedPreferences.
  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    talkBackEnabled.value = prefs.getBool(_keyTalkBack) ?? true;
    final themeIdx = prefs.getInt(_keyTheme) ?? 0;
    currentTheme.value = AppThemeType.values[
        themeIdx.clamp(0, AppThemeType.values.length - 1)];
  }

  /// Activa o desactiva TalkBack y persiste la preferencia.
  static Future<void> setTalkBack(bool enabled) async {
    talkBackEnabled.value = enabled;
    if (!enabled) await TtsService.instance.stop();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyTalkBack, enabled);
  }

  /// Cambia el tema de la aplicación y persiste la preferencia.
  static Future<void> setTheme(AppThemeType theme) async {
    currentTheme.value = theme;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyTheme, theme.index);
  }
}

/// Temas disponibles en GESACAD.
enum AppThemeType {
  blue,   // Azul institucional (por defecto)
  green,  // Verde naturaleza
  purple, // Morado académico
  dark,   // Modo oscuro
}

extension AppThemeTypeExt on AppThemeType {
  String get label {
    switch (this) {
      case AppThemeType.blue: return 'Azul Institucional';
      case AppThemeType.green: return 'Verde Naturaleza';
      case AppThemeType.purple: return 'Morado Académico';
      case AppThemeType.dark: return 'Modo Oscuro';
    }
  }

  Color get primaryColor {
    switch (this) {
      case AppThemeType.blue: return const Color(0xFF1A237E);
      case AppThemeType.green: return const Color(0xFF1B5E20);
      case AppThemeType.purple: return const Color(0xFF4A148C);
      case AppThemeType.dark: return const Color(0xFF212121);
    }
  }

  Color get secondaryColor {
    switch (this) {
      case AppThemeType.blue: return const Color(0xFF3949AB);
      case AppThemeType.green: return const Color(0xFF43A047);
      case AppThemeType.purple: return const Color(0xFF8E24AA);
      case AppThemeType.dark: return const Color(0xFF424242);
    }
  }

  List<Color> get gradient {
    switch (this) {
      case AppThemeType.blue: return [const Color(0xFF0D1B6E), const Color(0xFF3949AB)];
      case AppThemeType.green: return [const Color(0xFF1B5E20), const Color(0xFF43A047)];
      case AppThemeType.purple: return [const Color(0xFF4A148C), const Color(0xFF8E24AA)];
      case AppThemeType.dark: return [const Color(0xFF1A1A2E), const Color(0xFF16213E)];
    }
  }

  IconData get icon {
    switch (this) {
      case AppThemeType.blue: return Icons.water_drop_rounded;
      case AppThemeType.green: return Icons.eco_rounded;
      case AppThemeType.purple: return Icons.auto_awesome_rounded;
      case AppThemeType.dark: return Icons.dark_mode_rounded;
    }
  }
}
