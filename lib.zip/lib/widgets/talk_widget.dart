import 'dart:async';
import 'package:flutter/material.dart';
import '../services/tts_service.dart';
import '../services/settings_service.dart';

/// Widget que activa la lectura en voz alta al pasar el cursor encima (hover).
///
/// Comportamiento:
/// - Si TalkBack está desactivado en ajustes, el widget no hace nada.
/// - El cursor debe permanecer sobre el widget [delayMs] milisegundos antes
///   de activar la lectura (evita lecturas accidentales al pasar el cursor).
/// - Al salir del cursor, cancela el timer y detiene la lectura.
/// - Opcionalmente muestra un resalte visual al hacer hover ([highlightOnHover]).
class TalkWidget extends StatefulWidget {
  /// Widget hijo que se envuelve con la detección de hover.
  final Widget child;

  /// Texto que se leerá en voz alta al hacer hover.
  final String label;

  /// Tiempo de espera en milisegundos antes de iniciar la lectura.
  final int delayMs;

  /// Si es true, muestra un resalte visual sutil al hacer hover.
  final bool highlightOnHover;

  const TalkWidget({
    super.key,
    required this.child,
    required this.label,
    this.delayMs = 400,
    this.highlightOnHover = false,
  });

  @override
  State<TalkWidget> createState() => _TalkWidgetState();
}

class _TalkWidgetState extends State<TalkWidget> {
  /// Timer que espera antes de activar la lectura.
  Timer? _timer;

  /// Indica si el cursor está actualmente sobre el widget.
  bool _hovering = false;

  @override
  void dispose() {
    // Cancelar el timer pendiente al destruir el widget
    _timer?.cancel();
    super.dispose();
  }

  /// Se llama cuando el cursor entra al área del widget.
  void _alEntrar(PointerEvent _) {
    // Si TalkBack está desactivado, no hacer nada
    if (!AppSettings.talkBackEnabled.value) return;

    setState(() => _hovering = true);
    _timer?.cancel();

    // Iniciar timer: si el cursor permanece [delayMs] ms, iniciar lectura
    _timer = Timer(Duration(milliseconds: widget.delayMs), () {
      if (!mounted) return;
      if (AppSettings.talkBackEnabled.value) {
        TtsService.instance.speak(widget.label);
      }
    });
  }

  /// Se llama cuando el cursor sale del área del widget.
  void _alSalir(PointerEvent _) {
    setState(() => _hovering = false);

    // Cancelar el timer para evitar lecturas tardías
    _timer?.cancel();

    // Detener la lectura si el usuario salió del widget rápidamente
    // Solo detener si estaba leyendo este widget (no interrumpir otros)
    if (TtsService.instance.leyendo) {
      TtsService.instance.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: _alEntrar,
      onExit:  _alSalir,
      cursor:  SystemMouseCursors.basic,
      child: widget.highlightOnHover
          ? AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              decoration: _hovering
                  ? BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withOpacity(0.12),
                          blurRadius: 14,
                          spreadRadius: 2,
                        ),
                      ],
                    )
                  : null,
              child: widget.child,
            )
          : widget.child,
    );
  }
}
