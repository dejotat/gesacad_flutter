import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/tts_service.dart';
import '../services/settings_service.dart';

/// Botón flotante de TalkBack — lee en voz alta toda la pantalla actual.
///
/// Comportamiento:
/// - Solo aparece cuando TalkBack está activado en Ajustes.
/// - Al presionar: lee el texto de la pantalla actual.
/// - Mientras lee: anima con pulso y muestra botón "Detener".
/// - Al presionar de nuevo: detiene la lectura inmediatamente.
/// - Si TalkBack se desactiva desde Ajustes mientras está leyendo,
///   detiene la lectura y desaparece automáticamente.
///
/// IMPORTANTE: Solo debe haber UN TtsButton por pantalla (en el FAB).
/// No agregar otro botón TalkBack en ninguna otra parte de la pantalla.
class TtsButton extends StatefulWidget {
  /// Texto completo que se leerá al presionar el botón.
  final String text;

  const TtsButton({super.key, required this.text});

  @override
  State<TtsButton> createState() => _TtsButtonState();
}

class _TtsButtonState extends State<TtsButton>
    with SingleTickerProviderStateMixin {
  /// Indica si el botón está en estado "leyendo" activamente.
  bool _leyendo = false;

  /// Controlador para la animación de pulso mientras lee.
  late AnimationController _pulso;
  late Animation<double> _escala;

  @override
  void initState() {
    super.initState();

    // Animación de pulso suave: el botón crece y decrece mientras lee
    _pulso = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _escala = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulso, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulso.dispose();
    // Detener cualquier lectura pendiente al destruir el widget
    TtsService.instance.stop();
    super.dispose();
  }

  /// Alterna entre leer y detener la lectura.
  Future<void> _alternar(BuildContext ctx) async {
    if (_leyendo) {
      // ── Detener lectura ──────────────────────────────────────────────
      await TtsService.instance.stop();
      if (!mounted) return;
      setState(() => _leyendo = false);

      // Notificación visual de desactivación
      ScaffoldMessenger.of(ctx).clearSnackBars();
      ScaffoldMessenger.of(ctx).showSnackBar(
        SnackBar(
          content: Row(children: [
            const Text('🔇', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 10),
            Text('TalkBack detenido',
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600, color: Colors.white)),
          ]),
          backgroundColor: const Color(0xFFB71C1C),
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        ),
      );
    } else {
      // ── Iniciar lectura ──────────────────────────────────────────────
      setState(() => _leyendo = true);

      // Notificación visual de activación
      ScaffoldMessenger.of(ctx).clearSnackBars();
      ScaffoldMessenger.of(ctx).showSnackBar(
        SnackBar(
          content: Row(children: [
            const Text('🔊', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 10),
            Text('Leyendo pantalla en voz alta...',
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600, color: Colors.white)),
          ]),
          backgroundColor: const Color(0xFF1B5E20),
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        ),
      );

      // Leer el texto de la pantalla (await espera a que termine)
      await TtsService.instance.speak(widget.text);

      // Cuando termina la lectura, regresar al estado inicial
      if (mounted) setState(() => _leyendo = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: AppSettings.talkBackEnabled,
      builder: (ctx, activado, __) {
        // ── TalkBack desactivado: detener y ocultar el botón ────────────
        if (!activado) {
          if (_leyendo) {
            // Detener lectura en el próximo frame (no durante build)
            Future.microtask(() async {
              await TtsService.instance.stop();
              if (mounted) setState(() => _leyendo = false);
            });
          }
          // Devolver vacío — el botón desaparece completamente
          return const SizedBox.shrink();
        }

        // ── TalkBack activado: mostrar el botón ─────────────────────────
        final Color colorActivo  = const Color(0xFFD32F2F); // Rojo al leer
        final Color colorInactivo = const Color(0xFF1976D2); // Azul en reposo
        final Color colorActual   = _leyendo ? colorActivo : colorInactivo;

        return Semantics(
          label: _leyendo
              ? 'Detener lectura de pantalla'
              : 'Leer pantalla en voz alta',
          button: true,
          child: AnimatedBuilder(
            animation: _escala,
            builder: (_, hijo) => Transform.scale(
              // Solo animar con pulso cuando está leyendo
              scale: _leyendo ? _escala.value : 1.0,
              child: hijo,
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                gradient: LinearGradient(
                  colors: _leyendo
                      ? [colorActivo, const Color(0xFF7B1111)]
                      : [colorInactivo, const Color(0xFF0D47A1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  // Sombra principal con color del estado actual
                  BoxShadow(
                    color: colorActual.withOpacity(0.55),
                    blurRadius: _leyendo ? 28 : 16,
                    offset: const Offset(0, 6),
                  ),
                  // Brillo superior sutil
                  BoxShadow(
                    color: Colors.white.withOpacity(0.12),
                    blurRadius: 4,
                    offset: const Offset(0, -1),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _alternar(context),
                  borderRadius: BorderRadius.circular(32),
                  splashColor: Colors.white24,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 14),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Ícono animado: cambia entre 🔊 y 🛑
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 220),
                          child: Text(
                            _leyendo ? '🛑' : '🔊',
                            key: ValueKey(_leyendo),
                            style: const TextStyle(fontSize: 20),
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Texto animado: cambia entre "TalkBack" y "Detener"
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 220),
                          child: Text(
                            _leyendo ? 'Detener' : 'TalkBack',
                            key: ValueKey(_leyendo),
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
