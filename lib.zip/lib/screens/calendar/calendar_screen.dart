import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../services/settings_service.dart';

/// Evento del calendario académico.
class CalendarEvent {
  final String title;
  final EventType type;
  final String? description;
  final String? course;

  const CalendarEvent({
    required this.title,
    required this.type,
    this.description,
    this.course,
  });
}

enum EventType { exam, assignment, class_, holiday, event }

extension EventTypeExt on EventType {
  Color get color {
    switch (this) {
      case EventType.exam: return const Color(0xFFE53935);
      case EventType.assignment: return const Color(0xFF1565C0);
      case EventType.class_: return const Color(0xFF2E7D32);
      case EventType.holiday: return const Color(0xFF6A1B9A);
      case EventType.event: return const Color(0xFFE65100);
    }
  }
  IconData get icon {
    switch (this) {
      case EventType.exam: return Icons.quiz_rounded;
      case EventType.assignment: return Icons.assignment_rounded;
      case EventType.class_: return Icons.school_rounded;
      case EventType.holiday: return Icons.celebration_rounded;
      case EventType.event: return Icons.event_rounded;
    }
  }
  String get label {
    switch (this) {
      case EventType.exam: return 'Examen';
      case EventType.assignment: return 'Entrega';
      case EventType.class_: return 'Clase';
      case EventType.holiday: return 'Festivo';
      case EventType.event: return 'Evento';
    }
  }
}

/// Calendario académico con eventos marcados por tipo.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focused = DateTime.now();
  DateTime _selected = DateTime.now();
  CalendarFormat _format = CalendarFormat.month;

  late final Map<DateTime, List<CalendarEvent>> _events;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _events = {
      _day(now, 0): [
        const CalendarEvent(title: 'Clase de Cálculo', type: EventType.class_, course: 'Cálculo Diferencial'),
      ],
      _day(now, 2): [
        const CalendarEvent(title: 'Entrega Taller 2', type: EventType.assignment, description: 'Sección 4.1 a 4.5', course: 'Sistemas de Info'),
        const CalendarEvent(title: 'Quiz Lógica', type: EventType.exam, course: 'Lógica de Programación'),
      ],
      _day(now, 5): [
        const CalendarEvent(title: 'Parcial 1 — Cálculo', type: EventType.exam, description: 'Capítulos 1, 2 y 3', course: 'Cálculo Diferencial'),
      ],
      _day(now, 7): [
        const CalendarEvent(title: 'Feria de Emprendimiento', type: EventType.event, description: 'Auditorio principal — 8am a 5pm'),
      ],
      _day(now, 10): [
        const CalendarEvent(title: 'Proyecto final — BD', type: EventType.assignment, course: 'Bases de Datos'),
      ],
      _day(now, 14): [
        const CalendarEvent(title: 'Festivo universitario', type: EventType.holiday),
      ],
      _day(now, 16): [
        const CalendarEvent(title: 'Examen final', type: EventType.exam, course: 'Sistemas de Info'),
        const CalendarEvent(title: 'Clase de Arquitectura', type: EventType.class_, course: 'Arq. de Computadores'),
      ],
    };
  }

  DateTime _day(DateTime base, int offsetDays) =>
      DateTime(base.year, base.month, base.day + offsetDays);

  DateTime _normalizeDay(DateTime d) => DateTime(d.year, d.month, d.day);

  List<CalendarEvent> _eventsFor(DateTime day) =>
      _events[_normalizeDay(day)] ?? [];

  @override
  Widget build(BuildContext context) {
    final themeType = AppSettings.currentTheme.value;
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedEvents = _eventsFor(_selected);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Regresar',
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Calendario Académico',
            style: GoogleFonts.poppins(
                color: Colors.white, fontWeight: FontWeight.w700)),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: themeType.gradient,
                begin: Alignment.centerLeft,
                end: Alignment.centerRight),
          ),
        ),
        backgroundColor: Colors.transparent,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Leyenda de tipos
            _buildLegend(),
            // Calendario
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E1E2E) : Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.07),
                      blurRadius: 14, offset: const Offset(0, 4)),
                ],
              ),
              child: TableCalendar<CalendarEvent>(
                locale: 'es_ES',
                firstDay: DateTime.utc(2024, 1, 1),
                lastDay: DateTime.utc(2026, 12, 31),
                focusedDay: _focused,
                selectedDayPredicate: (d) => isSameDay(d, _selected),
                calendarFormat: _format,
                eventLoader: _eventsFor,
                startingDayOfWeek: StartingDayOfWeek.monday,
                onDaySelected: (sel, foc) =>
                    setState(() { _selected = sel; _focused = foc; }),
                onFormatChanged: (f) => setState(() => _format = f),
                onPageChanged: (f) => setState(() => _focused = f),
                headerStyle: HeaderStyle(
                  titleCentered: true,
                  formatButtonDecoration: BoxDecoration(
                    border: Border.all(color: primary),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  formatButtonTextStyle: GoogleFonts.poppins(
                      color: primary, fontSize: 12),
                  titleTextStyle: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700, fontSize: 15),
                  leftChevronIcon: Icon(Icons.chevron_left_rounded, color: primary),
                  rightChevronIcon: Icon(Icons.chevron_right_rounded, color: primary),
                ),
                calendarStyle: CalendarStyle(
                  todayDecoration: BoxDecoration(
                    color: primary.withOpacity(0.25),
                    shape: BoxShape.circle,
                  ),
                  selectedDecoration: BoxDecoration(
                    gradient: LinearGradient(colors: themeType.gradient),
                    shape: BoxShape.circle,
                  ),
                  markerDecoration: BoxDecoration(
                    color: primary, shape: BoxShape.circle,
                  ),
                  todayTextStyle: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700, color: primary),
                  selectedTextStyle: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700, color: Colors.white),
                  defaultTextStyle: GoogleFonts.poppins(fontSize: 13),
                  weekendTextStyle: GoogleFonts.poppins(
                      color: Colors.red.shade400, fontSize: 13),
                  outsideTextStyle: GoogleFonts.poppins(
                      color: Colors.grey.shade400, fontSize: 13),
                ),
                daysOfWeekStyle: DaysOfWeekStyle(
                  weekdayStyle: GoogleFonts.poppins(
                      fontSize: 11, fontWeight: FontWeight.w600),
                  weekendStyle: GoogleFonts.poppins(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Colors.red.shade400),
                ),
              ),
            ),

            // Eventos del día seleccionado
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Row(children: [
                Icon(Icons.today_rounded, color: primary, size: 20),
                const SizedBox(width: 8),
                Text(
                  _formatDate(_selected),
                  style: GoogleFonts.poppins(
                      fontSize: 15, fontWeight: FontWeight.w700, color: primary),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${selectedEvents.length} evento${selectedEvents.length == 1 ? '' : 's'}',
                    style: GoogleFonts.poppins(
                        fontSize: 12, color: primary, fontWeight: FontWeight.w600),
                  ),
                ),
              ]),
            ),

            if (selectedEvents.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  Icon(Icons.event_available_rounded,
                      size: 48, color: Colors.grey.shade300),
                  const SizedBox(height: 8),
                  Text('Sin eventos este día',
                      style: GoogleFonts.poppins(
                          color: Colors.grey.shade400, fontSize: 14)),
                ]),
              )
            else
              ...selectedEvents.map((e) => _buildEventTile(e, isDark)),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildLegend() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: EventType.values.map((t) => Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Row(children: [
              Container(width: 10, height: 10,
                  decoration: BoxDecoration(
                      color: t.color, shape: BoxShape.circle)),
              const SizedBox(width: 5),
              Text(t.label,
                  style: GoogleFonts.poppins(
                      fontSize: 11, color: Colors.grey.shade600)),
            ]),
          )).toList(),
        ),
      ),
    );
  }

  Widget _buildEventTile(CalendarEvent event, bool isDark) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E1E2E) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: event.type.color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
              color: event.type.color.withOpacity(0.08),
              blurRadius: 10, offset: const Offset(0, 3)),
        ],
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: event.type.color.withOpacity(0.12),
            shape: BoxShape.circle,
          ),
          child: Icon(event.type.icon, color: event.type.color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: event.type.color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(event.type.label,
                    style: GoogleFonts.poppins(
                        fontSize: 10, color: event.type.color,
                        fontWeight: FontWeight.w600)),
              ),
            ]),
            const SizedBox(height: 5),
            Text(event.title,
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w700, fontSize: 14)),
            if (event.course != null) ...[
              const SizedBox(height: 2),
              Text(event.course!,
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: event.type.color)),
            ],
            if (event.description != null) ...[
              const SizedBox(height: 4),
              Text(event.description!,
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: Colors.grey.shade500)),
            ],
          ]),
        ),
      ]),
    );
  }

  String _formatDate(DateTime d) {
    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves',
        'Viernes', 'Sábado', 'Domingo'];
    final wd = d.weekday - 1;
    return '${dias[wd]}, ${d.day} de ${meses[d.month - 1]}';
  }
}
